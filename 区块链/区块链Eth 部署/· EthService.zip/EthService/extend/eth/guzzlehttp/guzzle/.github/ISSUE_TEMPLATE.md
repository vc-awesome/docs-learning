| Q            | A
| ------------ | ---
| Bug?         | no|yes
| New Feature? | no|yes
| Version      | Specific version or SHA of a commit


#### Actual Behavior

What is the actual behavior?


#### Expected Behavior

What is the behavior you expect?


#### Steps to Reproduce

What are the steps to reproduce this bug? Please add code examples,
screenshots or links to GitHub repositories that reproduce the problem.


#### Possible Solutions

If you have already ideas how to solve the issue, add them here.
(remove this section if not needed)
