<?php

return [
    'address'      => '0xdae80b3cf7ead1f6174ea038c15d8f91cc4e98db',
    'keystore'     => '../keystore/dae80b3cf7ead1f6174ea038c15d8f91cc4e98db.json',
    'eth_pwd'      => 'c36fGdDJOQ5L+UGscMqGGWv/2jQmCXpGc6qBA6IP5PkOxGw',
    'eth_key'      => 'werwqesd45',
    'boss_address' => '0xB90c7b4c465c0cB9Edc84329604FDCF41Df787f5',
];