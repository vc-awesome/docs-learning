<?php

namespace app\app\controller;

use think\Db;

class Index
{
    public function download()
    {
        $json_info = file_get_contents("http://nait.cocofvif.com/home/index/index");
        $json_arr = json_decode($json_info, true);
        return view()->assign(['and_url' => $json_arr['data']['and_url']]);
    }
}
