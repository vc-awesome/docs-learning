<?php /*a:1:{s:64:"/www/wwwroot/EthService/application/app/view/index/download.html";i:1616492219;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
		<title>NAIT</title>
		<style type="text/css">
			.body{
				margin: 0;
				padding:0;
				height: 100vh;
				width: 100%;
				background: url(/static/app/img/down.png) no-repeat center;
				background-size: 100% 100%;
			}
			a{
				text-decoration: none;
				color:#000;
			}
			.img {
				width: 100%;
				font-size: 0;
			}

			.main .btn {
				width: 100%;
				position: fixed;
				bottom: 80px;
				left: 7%;
				right: 7%;
			}
			.blue{
				width: 86%;
				height: 40px;
				line-height: 40px;
				text-align: center;
				font-size: 16px;
				display: flex;
				align-items: center;
				justify-content: center;
				background: linear-gradient(#324ED4, #00EBE7);
				margin-bottom:25px;
				color: #fff;
				border-radius: 5px;
			}
			.green{
				width: 86%;
				height: 40px;
				line-height: 40px;
				text-align: center;
				font-size: 16px;
				display: flex;
				align-items: center;
				justify-content: center;
				background: transparent;
				border:1px solid #324ED4;
				border-radius: 5px;
				color: #fff;
			}
			
		</style>
	</head>

	<body class="body">
		<div class="main">
			<div>
				<div style="text-align: center;padding-top: 35%">
					<img src="/static/app/img/LOGO.png" style="width: 50%;" />
				</div>
				<h4 style="color:#fff;text-align: center;font-size: 18px;">下载新奈特、获得更多盈利！</h4>
				<div class="btn">
					<!-- <a href="itms-services://?action=download-manifest&url=https://forcetf-domestic.oss-cn-shenzhen.aliyuncs.com/app.plist&v=<?php echo time(); ?>" class="item">
						IOS 下载
					</a> -->
					<a href="<?php echo htmlentities($and_url); ?>" class="item blue">
						<img src="/static/app/img/az.png" style="width: 18px;margin-right: 10px;" /> 安卓下载
					</a>
					<a href="#" class="item green" onclick="alert('暂不支持')">
						<img src="/static/app/img/ios.png" style="width: 18px;margin-right: 10px;" /> 苹果下载
					</a>
				</div>
			</div>
		</div>
	</body>
</html>
