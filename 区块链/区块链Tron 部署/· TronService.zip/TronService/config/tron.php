<?php

return [
    'address'=>'TTsfe97Ym2JkhV9YoMwyfJJmScDLC4gQV6',
    'private_key'=>'b88c7a8d6f1255497d89bcb80c0ebee6150e26edb8a06d2ef9df945f87736ea0',
    'public_key'=>'045c96a990c2d4b23172a806bcc5066fed4781ea6dc534d23b67e37d4f74aa7c678da334223345699a8805b3d96fb5d1cf96ee313bebbf1b7b9fc4718af3f6b903',
    'key' => 'Dsad895711',
    // 'boss_address'=>'TWuG4q3yLURUyi763SKQzK1LuAYjRbRAmj',
    'boss_address'=>'TYUeVzbtZyx9zza5midR3ZkEoYJpXMXGse',
];